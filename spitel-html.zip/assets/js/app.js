$(document).ready(function () {

    $('.technology-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 990,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 760,
                settings: {
                    slidesToShow: 1,
                }
            },
        ]
    })

})

$(window).on('load', function() {
    $('.app-preloader').fadeOut(500)
    setTimeout(() => {
        $('.navigation-wrapper').removeClass('is-loaded')
    }, 500);
})

$(window).on('scroll', function () {
    var scroll = $(window).scrollTop();
    if (scroll > 100) {
        $('.navigation-wrapper').addClass('active')
    }
    else {
        $('.navigation-wrapper').removeClass('active')
    }
})